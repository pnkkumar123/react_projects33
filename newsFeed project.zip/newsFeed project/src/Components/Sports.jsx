import React from 'react'

const Sports = () => {
  return (
    <div>Sports</div>
  )
}

export default Sports